#include <Arduino.h>
#include <Wire.h>
#include <SparkFun_MicroPressure.h> 
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Vector.h>

#define EOC_PIN  -1
#define RST_PIN  -1
#define MIN_PSI   0
#define MAX_PSI   25

Adafruit_MPU6050 mpu;

int motor1Pin1 = 27; 
int motor1Pin2 = 26;
int VCC_Pressure = 17;
int VCC_Acceleration = 16;
int largePumpDelay = 10000;
int smallPumpDelay = 1000;
int pumpingLED = 39; 
int deflatingLED = 34;  
int servoPin = 10; 

float sensor_pressure; 
float adjusted_pressure; 

Vector<float> PressureReadings; 
Vector<float> timings; 

boolean pumping_flag; 

SparkFun_MicroPressure mpr(EOC_PIN, RST_PIN, MIN_PSI, MAX_PSI);

void setup() {
  // put your setup code here, to run once:
  pinMode(VCC_Pressure, OUTPUT);
  pinMode(VCC_Acceleration, OUTPUT);

  Serial.begin(115200);
  while (!Serial)
    delay(10); // will pause Zero, Leonardo, etc until serial console opens

  // Serial.println("Adafruit MPU6050 test!");
  
  digitalWrite(VCC_Pressure, HIGH); 
  delay(1000);

  Serial.println("Connecting to MicroPressure sensor...");
  Wire.begin(); 
  if(!mpr.begin())
  {
    Serial.println("Cannot connect to MicroPressure sensor.");
    while(1);
  }

  digitalWrite(VCC_Acceleration, HIGH); 
  delay(1000);

  Serial.println("Connecting to MPU6050...");
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) {
      delay(10);
    }
  }
  Serial.println("MPU6050 Found!");

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  Serial.print("Accelerometer range set to: ");
  switch (mpu.getAccelerometerRange()) {
  case MPU6050_RANGE_2_G:
    Serial.println("+-2G");
    break;
  case MPU6050_RANGE_4_G:
    Serial.println("+-4G");
    break;
  case MPU6050_RANGE_8_G:
    Serial.println("+-8G");
    break;
  case MPU6050_RANGE_16_G:
    Serial.println("+-16G");
    break;
  }
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  Serial.print("Gyro range set to: ");
  switch (mpu.getGyroRange()) {
  case MPU6050_RANGE_250_DEG:
    Serial.println("+- 250 deg/s");
    break;
  case MPU6050_RANGE_500_DEG:
    Serial.println("+- 500 deg/s");
    break;
  case MPU6050_RANGE_1000_DEG:
    Serial.println("+- 1000 deg/s");
    break;
  case MPU6050_RANGE_2000_DEG:
    Serial.println("+- 2000 deg/s");
    break;
  }

  mpu.setFilterBandwidth(MPU6050_BAND_5_HZ);
  Serial.print("Filter bandwidth set to: ");
  switch (mpu.getFilterBandwidth()) {
  case MPU6050_BAND_260_HZ:
    Serial.println("260 Hz");
    break;
  case MPU6050_BAND_184_HZ:
    Serial.println("184 Hz");
    break;
  case MPU6050_BAND_94_HZ:
    Serial.println("94 Hz");
    break;
  case MPU6050_BAND_44_HZ:
    Serial.println("44 Hz");
    break;
  case MPU6050_BAND_21_HZ:
    Serial.println("21 Hz");
    break;
  case MPU6050_BAND_10_HZ:
    Serial.println("10 Hz");
    break;
  case MPU6050_BAND_5_HZ:
    Serial.println("5 Hz");
    break;
  }

  Serial.println("");
  delay(100);

  pinMode(motor1Pin1, OUTPUT);
  pinMode(motor1Pin2, OUTPUT);
  pinMode(pumpingLED, OUTPUT); 
  pinMode(deflatingLED, OUTPUT); 
}

float convToGage(float sensor_pressure)
{
  float adjusted_pressure = sensor_pressure - 748; 
  adjusted_pressure = abs(adjusted_pressure); 

  return adjusted_pressure;  
}

void largePump()
{
  Serial.println("Large Pump");
  digitalWrite(motor1Pin1, LOW);
  digitalWrite(motor1Pin2, HIGH); 
  digitalWrite(pumpingLED, HIGH);
  delay(largePumpDelay);
}

void smallPump()
{
  Serial.println("Small Pump");
  digitalWrite(motor1Pin1, LOW);
  digitalWrite(motor1Pin2, HIGH); 
  digitalWrite(pumpingLED, HIGH);
  delay(smallPumpDelay);
}

void stopPump()
{
  // Stop the DC motor
  digitalWrite(motor1Pin1, LOW);
  digitalWrite(motor1Pin2, LOW);
  digitalWrite(pumpingLED, LOW);
  Serial.println("Motor stopped");
}

void loop() {
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);
  sensor_pressure = (mpr.readPressure(INHG)*25.4);
  adjusted_pressure = convToGage(sensor_pressure); 
   
  Serial.print(adjusted_pressure);
  Serial.println(";");
  delay(100);

  // Pump air in
  if(adjusted_pressure < 150 && pumping_flag == true)
  {
    largePump(); 
  }
  else if (adjusted_pressure < 200 && pumping_flag == true)
  {
    smallPump();
  }
  else
  {
    pumping_flag = false; 
  }
  
  // Start Deflating
  int n = 0;  
  while(n < 10000){
    sensor_pressure = (mpr.readPressure(INHG)*25.4);
    adjusted_pressure = convToGage(sensor_pressure); 
    PressureReadings.push_back(adjusted_pressure); 
  }  


}